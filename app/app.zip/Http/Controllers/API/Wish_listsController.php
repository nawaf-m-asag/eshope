<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Ec_wish_list;

class Wish_listsController extends Controller
{
    public function _setFav(Request $request)
    {
        $error=false;
        $request = json_decode(file_get_contents("php://input"));
        $customer_id = isset($request->user_id)? $request->user_id:$error=True;
        $product_id = isset($request->product_id)? $request->product_id:$error=True;
  
        $data=[
            'customer_id'=>$customer_id,    
            'product_id'=>$product_id,
            ];
            
  
        $ec_wish_lists=Ec_wish_list::create($data);
    
             if($ec_wish_lists){
                $message="Added to favorite";
            }
            else{
                $message="Not Added to favorite";
                $error=true;
            }
            
            return response()->json(
                [
                    'error'=>$error,
                    'message'=>$message,
                    'data'=>[],
                ], 200);

    }   
}
