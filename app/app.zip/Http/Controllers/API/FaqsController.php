<?php

namespace App\Http\Controllers\API;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Faq;

class FaqsController extends Controller
{
    public function getFaqs(Request $request)
    {
        $faqs= Faq::where("status","published")->orderBy("id","desc")->get();
        $total= Faq::where("status","published")->count();
             if(!$faqs->isEmpty()){
                $message="FAQ(s) Retrieved Successfully";
            }
            else{
                $message="FAQ(s) Retrieved is Empty";
            }
            $data=Faq::get_faqs_json_data($faqs);
            return response()->json(
                [
                    'message'=>$message,
                    'error'=>false,
                    'total'=>"$total",
                    'data'=>$data,
                ], 200);

    }   
}
