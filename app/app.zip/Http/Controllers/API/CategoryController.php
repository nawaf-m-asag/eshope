<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Ec_product_category;
use RvMedia;

class CategoryController
{
    public function getCat(Request $request)
    {
        
            $request = json_decode(file_get_contents("php://input"));

             $has_child_or_item =isset($request->has_child_or_item)?$request->has_child_or_item:0;
             $offset = isset($request->offset)? $request->offset: 0;
             $limit = isset($request->limit)? $request->limit: 30;

            $categories= Ec_product_category::limit($limit)->offset($offset)->where("status","published")->where("parent_id",0)->orderBy("order")->get();
            $total= Ec_product_category::where("status","published")->count();
           
    
            if(!$categories->isEmpty()){
                $message="Category retrieved successfully";
            }
            else{
                $message="Category retrieved no data";
            }

          $data=  Ec_product_category::get_category_json_data($categories,$has_child_or_item,0);

            return response()->json(
                [
                    'message'=>$message,
                    'error'=>false,
                    'total'=>$total,
                    'data'=>$data,
    
                ], 200);
    }
  
}
